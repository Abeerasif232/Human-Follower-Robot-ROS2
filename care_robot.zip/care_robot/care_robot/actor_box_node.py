import rclpy
from rclpy.node import Node
from gazebo_msgs.srv import SetEntityState
from gazebo_msgs.msg import ModelStates
from geometry_msgs.msg import Pose, Quaternion

class ActorBoxFollower(Node):
    def __init__(self):
        super().__init__('actor_box_follower')
        self.actor_name = 'actor'
        self.box_name = 'actor_collision_box'

        # Create a client for the /set_entity_state service
        self.client = self.create_client(SetEntityState, '/set_entity_state')

        # Wait for the service to be available
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /set_entity_state service...')

        # Subscribe to the /gazebo/model_states topic
        self.subscription = self.create_subscription(
            ModelStates,
            '/model_states',
            self.state_callback,
            10
        )

    def state_callback(self, msg):
        try:
            # Find the index of the actor in the list of model names
            actor_index = msg.name.index(self.actor_name)
            actor_pose = msg.pose[actor_index]

            # Log the actor's pose
            self.get_logger().info(f"Actor Pose: {actor_pose}")

            # Prepare the box's new pose based on actor's pose
            box_pose = Pose(
                position=actor_pose.position,  # Use actor's position
                orientation=Quaternion(x=0.0, y=0.0, z=0.0, w=0.0)  # Keep orientation simple
            )

            # Create a request to update the box's state
            request = SetEntityState.Request()
            request.state.name = self.box_name
            request.state.pose = box_pose

            # Call the service to update the box's position
            self.client.call_async(request)

        except ValueError:
            self.get_logger().warn(f"{self.actor_name} not found in /gazebo/model_states")

def main(args=None):
    rclpy.init(args=args)
    node = ActorBoxFollower()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
