import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import cv2
import numpy as np

class GreenShirtFollower(Node):
    def __init__(self):
        super().__init__('green_shirt_follower')
        self.bridge = CvBridge()

        # Subscribers
        self.create_subscription(Image, '/robot_camera/image_raw', self.rgb_callback, 10)
        self.create_subscription(Image, '/robot_camera/depth/image_raw', self.depth_callback, 10)

        # Publisher
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.depth_image = None
        self.image_width = 640
        self.center_x = self.image_width // 2
        self.deadzone = 50

        self.get_logger().info("Green Shirt Follower Node Started")

    def depth_callback(self, msg):
        try:
            self.depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')
        except Exception as e:
            self.get_logger().error(f"Depth conversion error: {e}")

    def rgb_callback(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception as e:
            self.get_logger().error(f"RGB conversion error: {e}")
            return

        if self.depth_image is None:
            return

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # HSV range for dark green
        lower_green = np.array([30, 30, 20])
        upper_green = np.array([90, 255, 200])

        mask = cv2.inRange(hsv, lower_green, upper_green)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        twist = Twist()

        if contours:
            # Filter out small blobs
            large_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > 1000]

            if large_contours:
                largest = max(large_contours, key=cv2.contourArea)
                M = cv2.moments(largest)

                if M['m00'] != 0:
                    cx = int(M['m10'] / M['m00'])
                    cy = int(M['m01'] / M['m00'])

                    # Strictly place red dot at centroid only
                    cv2.circle(frame, (cx, cy), 10, (0, 0, 255), -1)

                    # Show blue center line
                    cv2.line(frame, (self.center_x, 0), (self.center_x, frame.shape[0]), (255, 0, 0), 2)

                    # Get average depth
                    window = self.depth_image[max(0, cy - 2):cy + 3, max(0, cx - 2):cx + 3]
                    valid_depths = window[np.isfinite(window) & (window > 0)]
                    if valid_depths.size > 0:
                        depth = np.mean(valid_depths) / 1000.0  # mm to m
                    else:
                        depth = 0.0

                    self.get_logger().info(f"Human centroid at ({cx},{cy}), Depth = {depth:.2f} m")

                    # Align first
                    error = cx - self.center_x
                    if abs(error) > self.deadzone:
                        twist.angular.z = -float(error) / 150.0
                        twist.linear.x = 0.0
                    else:
                        twist.angular.z = 0.0
                        twist.linear.x = 0.3 if depth == 0.0 or np.isnan(depth) else 0.3
        else:
            # Rotate to search
            twist.angular.z = -0.3
            twist.linear.x = 0.0

        self.cmd_pub.publish(twist)

        # Debug views
        cv2.imshow("Green Mask", mask)
        cv2.imshow("Camera View", frame)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    node = GreenShirtFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        cv2.destroyAllWindows()
        rclpy.shutdown()
