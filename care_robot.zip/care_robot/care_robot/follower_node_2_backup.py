import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import cv2
import numpy as np
import mediapipe as mp

class MediaPipeFollower(Node):
    def __init__(self):
        super().__init__('mediapipe_human_follower')
        self.bridge = CvBridge()

        # Subscribers
        self.create_subscription(Image, '/robot_camera_sensor/image_raw', self.rgb_callback, 10)
        self.create_subscription(Image, '/robot_camera_sensor/depth/image_raw', self.depth_callback, 10)

        # Publisher
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        self.depth_image = None
        self.image_width = 640
        self.center_x = self.image_width // 2
        self.deadzone = 50

        # MediaPipe setup
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5)
        self.mp_draw = mp.solutions.drawing_utils

        self.get_logger().info("MediaPipe Human Follower Node Started")

    def depth_callback(self, msg):
        try:
            self.depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='passthrough')
        except Exception as e:
            self.get_logger().error(f"Depth conversion error: {e}")

    def rgb_callback(self, msg):
        self.get_logger().debug("RGB callback triggered")

        # Force OpenCV windows to open
        cv2.namedWindow("Camera View", cv2.WINDOW_NORMAL)
        cv2.namedWindow("Status", cv2.WINDOW_NORMAL)

        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception as e:
            self.get_logger().error(f"RGB conversion error: {e}")
            return

        if self.depth_image is None:
            return

        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.pose.process(image_rgb)

        twist = Twist()

        # Create status window image
        status_img = np.zeros((200, 400, 3), dtype=np.uint8)

        if results.pose_landmarks:
            # Use midpoint between shoulders as target point
            left_shoulder = results.pose_landmarks.landmark[self.mp_pose.PoseLandmark.LEFT_SHOULDER]
            right_shoulder = results.pose_landmarks.landmark[self.mp_pose.PoseLandmark.RIGHT_SHOULDER]

            cx = int((left_shoulder.x + right_shoulder.x) / 2 * frame.shape[1])
            cy = int((left_shoulder.y + right_shoulder.y) / 2 * frame.shape[0])

            # Draw landmarks and visual guides
            self.mp_draw.draw_landmarks(frame, results.pose_landmarks, self.mp_pose.POSE_CONNECTIONS)
            cv2.circle(frame, (cx, cy), 10, (0, 0, 255), -1)
            cv2.line(frame, (self.center_x, 0), (self.center_x, frame.shape[0]), (255, 0, 0), 2)

            # Get average depth
            window = self.depth_image[max(0, cy - 2):cy + 3, max(0, cx - 2):cx + 3]
            valid_depths = window[np.isfinite(window) & (window > 0)]
            if valid_depths.size > 0:
                depth = np.mean(valid_depths) / 1000.0  # mm to m
            else:
                depth = 0.0

            distance_text = f"Distance: {depth:.2f} m"
            self.get_logger().info(f"Human detected at ({cx},{cy}), {distance_text}")

            # Draw status messages
            cv2.putText(status_img, "Human Detected", (50, 100),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 3)
            cv2.putText(status_img, distance_text, (50, 150),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 255), 2)
            cv2.putText(frame, distance_text, (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 255), 2)

            # Movement decision
            error = cx - self.center_x
            if abs(error) > self.deadzone:
                twist.angular.z = -float(error) / 150.0
                twist.linear.x = 0.0
            else:
                twist.angular.z = 0.0
                twist.linear.x = 0.3 if depth == 0.0 or np.isnan(depth) else 0.3

        else:
            # No person detected
            twist.angular.z = -0.9
            twist.linear.x = 0.0
            cv2.putText(status_img, "Searching...", (70, 100),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 3)

        self.cmd_pub.publish(twist)

        # Show debug windows
        cv2.imshow("Camera View", frame)
        cv2.imshow("Status", status_img)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    node = MediaPipeFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        cv2.destroyAllWindows()
        rclpy.shutdown()
