import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PoseStamped, PointStamped, Twist
from cv_bridge import CvBridge
import cv2
import numpy as np
import mediapipe as mp
import tf2_ros
from tf2_ros import LookupException, ConnectivityException, ExtrapolationException
import tf2_geometry_msgs
import math

class HumanFollowerNav(Node):
    def __init__(self):
        super().__init__('human_follower_nav2')

        # Subscribers
        self.create_subscription(Image, '/robot_camera_sensor/image_raw', self.rgb_callback, 10)
        self.create_subscription(Image, '/robot_camera_sensor/depth/image_raw', self.depth_callback, 10)
        self.create_subscription(CameraInfo, '/robot_camera_sensor/camera_info', self.camera_info_callback, 10)

        # Publishers
        self.goal_pub    = self.create_publisher(PoseStamped, '/goal_pose', 10)
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # TF setup
        self.tf_buffer   = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # Bridge and storage
        self.bridge      = CvBridge()
        self.depth_image = None

        # MediaPipe pose detector
        self.pose_detector = mp.solutions.pose.Pose(
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )

        # Camera intrinsics (populated on CameraInfo callback)
        self.fx = self.fy = self.cx_intr = self.cy_intr = None

        # Config
        self.camera_frame         = 'camera_link'
        self.follow_distance      = 1.0    # meters
        self.goal_update_interval = 1.0    # seconds
        self.detection_timeout    = 3.0    # seconds without detection → rotate

        # Timing
        now = self.get_clock().now()
        self.last_goal_time      = now
        self.last_detection_time = now

        self.get_logger().info("HumanFollowerNav2 Node Started")

    def camera_info_callback(self, msg: CameraInfo):
        if self.fx is None:
            self.fx      = msg.k[0]
            self.fy      = msg.k[4]
            self.cx_intr = msg.k[2]
            self.cy_intr = msg.k[5]
            self.get_logger().info(
                f"Camera intrinsics: fx={self.fx:.1f}, fy={self.fy:.1f}, cx={self.cx_intr:.1f}, cy={self.cy_intr:.1f}"
            )

    def depth_callback(self, msg):
        try:
            self.depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='32FC1')
        except Exception as e:
            self.get_logger().error(f"Depth conversion error: {e}")

    def rgb_callback(self, msg):
        # Wait until we have intrinsics and a depth image
        if self.fx is None or self.depth_image is None:
            return

        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception as e:
            self.get_logger().error(f"RGB conversion error: {e}")
            return

        image_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results   = self.pose_detector.process(image_rgb)

        human_seen = False

        if results.pose_landmarks:
            lm = results.pose_landmarks.landmark
            left  = lm[mp.solutions.pose.PoseLandmark.LEFT_SHOULDER]
            right = lm[mp.solutions.pose.PoseLandmark.RIGHT_SHOULDER]
            cx = int((left.x + right.x) / 2 * frame.shape[1])
            cy = int((left.y + right.y) / 2 * frame.shape[0])

            # Sample depth in a small window
            window = self.depth_image[max(0, cy-2):cy+3, max(0, cx-2):cx+3]
            valid  = window[np.isfinite(window) & (window>0)]
            if valid.size == 0:
                return
            z_opt = float(np.mean(valid))  # depth in meters

            # Optical frame coords:
            x_opt = (cx - self.cx_intr) * z_opt / self.fx
            y_opt = (cy - self.cy_intr) * z_opt / self.fy

            # Convert to ROS camera_link frame (X forward, Y left, Z up):
            x_cam_link =  z_opt          # optical Z → ROS X
            y_cam_link = -x_opt          # optical X right → ROS Y left = -x_opt
            z_cam_link = -y_opt          # optical Y down → ROS Z up = -y_opt

            pt_cam = PointStamped()
            pt_cam.header.frame_id = self.camera_frame
            pt_cam.header.stamp    = msg.header.stamp
            pt_cam.point.x         = x_cam_link
            pt_cam.point.y         = y_cam_link
            pt_cam.point.z         = z_cam_link

            try:
                # Transform human to map
                tf_map_cam = self.tf_buffer.lookup_transform('map', self.camera_frame, rclpy.time.Time())
                human_map  = tf2_geometry_msgs.do_transform_point(pt_cam, tf_map_cam)

                # Get robot base_link in map
                tf_map_base = self.tf_buffer.lookup_transform('map', 'base_link', rclpy.time.Time())
                robot_x = tf_map_base.transform.translation.x
                robot_y = tf_map_base.transform.translation.y

                # Vector robot→human
                dx = human_map.point.x - robot_x
                dy = human_map.point.y - robot_y
                dist = math.hypot(dx, dy)
                if dist < 0.01:
                    return
                ux, uy = dx/dist, dy/dist

                # Compute follow-behind goal
                goal_x = human_map.point.x - ux * self.follow_distance
                goal_y = human_map.point.y - uy * self.follow_distance

                now = self.get_clock().now()
                self.last_detection_time = now
                human_seen = True

                # Throttle goal updates
                if (now - self.last_goal_time).nanoseconds / 1e9 < self.goal_update_interval:
                    return

                # Publish goal
                goal = PoseStamped()
                goal.header.frame_id = 'map'
                goal.header.stamp    = now.to_msg()
                goal.pose.position.x = goal_x
                goal.pose.position.y = goal_y
                goal.pose.position.z = 0.0
                goal.pose.orientation.w = 1.0

                self.goal_pub.publish(goal)
                self.last_goal_time = now
                self.stop_rotation()

                self.get_logger().info(
                    f"Robot=({robot_x:.2f},{robot_y:.2f}) "
                    f"Human=({human_map.point.x:.2f},{human_map.point.y:.2f}) "
                    f"→ Goal=({goal_x:.2f},{goal_y:.2f})"
                )

            except (LookupException, ConnectivityException, ExtrapolationException) as e:
                self.get_logger().warn(f"TF error: {e}")

        # If lost, rotate
        if not human_seen:
            since = (self.get_clock().now() - self.last_detection_time).nanoseconds / 1e9
            if since > self.detection_timeout:
                self.rotate_in_place()

        # Debug view
        cv2.imshow("HumanFollower", frame)
        cv2.waitKey(1)

    def rotate_in_place(self):
        twist = Twist()
        twist.angular.z = 0.4
        twist.linear.x  = 0.0
        self.cmd_vel_pub.publish(twist)

    def stop_rotation(self):
        twist = Twist()
        twist.angular.z = 0.0
        twist.linear.x  = 0.0
        self.cmd_vel_pub.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = HumanFollowerNav()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        cv2.destroyAllWindows()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
